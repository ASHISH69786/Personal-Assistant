import urllib
try :
    stri = "https://www.google.co.in"
    data = urllib.request.urlopen(stri)
    print("Connected")
except Exception as e:
    print("not connected" ,e)