import pyttsx3
import datetime
import speech_recognition as sr
import wikipedia
import webbrowser
import os
import socket
def is_connected():
    try:
        # connect to the host -- tells us if the host is actually
        # reachable
        socket.create_connection(("1.1.1.1", 53))
        
        return True
    except OSError:
        pass
    return False
engine=pyttsx3.init('sapi5') #take the voices from the windows
voices=engine.getProperty('voices')
engine.setProperty('voice',voices[1].id)
def speak(audio):
    engine.say(audio)
    engine.runAndWait()
def wishMe():
    hour=int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good morning Ashish")
    elif hour>=12 and hour<18:
        speak("good afternoon Ashish")
    else :
        speak("Good evening Ashish")
    speak("I am your assistant, How Can i help You")
def takecommand():
    r=sr.Recognizer()
    with sr.Microphone() as source:
         speak("Listening...")
         r.pause_threshold=1
         audio=r.listen(source)
   
    try:
        speak("Recogninzing")
        g=is_connected
        

        query=r.recognize_google(audio,language='en-in')
        speak(f"You said {query}")
       
    
    except Exception as e:
        #print(e)
        speak("sorry i am not able to understand you, please try to run your program again")
        
    
        speak("ooooooooh  ooooooh AAh AAH AAH AAH")
        return "None"
    return query
if __name__ == "__main__":
    speak("Hello!")
    wishMe()
    if True:
            query=takecommand().lower()
            if "wikipedia" in query:
                g= is_connected
                if g:
                    speak("searching wikipedia..")
                    query=query.replace("wikipedia","")
                    results=wikipedia.summary(query,sentences=2)
                    speak("According to wikipedia ")
                    speak(results)
                else:
                    speak("Please connect to internet first,I cant reach at the moment You bloddy fool")                
            elif 'open youtube' in query:
                g=is_connected
                if g:
                    speak("processing your request")
                    webbrowser.open("youtube.com")
                else:
                    speak("You mother fucker first connect to the internet, then ask me")
                
            elif 'open google' in query:
                g=is_connected
                if g:
                    webbrowser.open("google.com")
                else:
                    speak("oh! my fuck boy ashish you are not connected to internet, do you want to fuck me again ")

                
            elif 'play music' in query:
                music_dir="C:\\Users\\asiss\\OneDrive\\Desktop\\MY melodies"
                songs=os.listdir(music_dir)
                os.startfile(os.path.join(music_dir,songs[0]))
            elif "the time" in query:
                tim=datetime.datetime.now().strftime("%H:%M:%S")
                speak(f"My beloved Ashish the time is {tim}")
            elif "open code" in query:
                path_c="C:\\Users\\asiss\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
                os.startfile(path_c)
            