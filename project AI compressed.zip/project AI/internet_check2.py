import socket
def is_connected():
    try:
        # connect to the host -- tells us if the host is actually
        # reachable
        socket.create_connection(("1.1.1.1", 53))
        return True
    except OSError:
        pass
    return False
if __name__ == "__main__":
    g = is_connected()
    if g:
        print("connected to internet")
    else:
        print("not connected to internet")
    